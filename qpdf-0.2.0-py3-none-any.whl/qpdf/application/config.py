"""
application/config.py

Author: Benevant Mathew
Date: 2026-06-21
"""
dpi_value = 300