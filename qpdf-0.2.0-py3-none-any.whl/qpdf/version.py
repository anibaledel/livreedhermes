"""
qpdf/version.py

Author: Benevant Mathew
Date: 2026-06-21
"""

__version__ = "0.2.0"
__app_name__ = "QuantumPDF"
__app_folder__ = "qpdf"
__author__ = "Benevant Mathew"
__email__ = "benevantmathewv@gmail.com"
__release_date__ = "21-06-2026"

if __name__ == "__main__":
    print(__version__)
