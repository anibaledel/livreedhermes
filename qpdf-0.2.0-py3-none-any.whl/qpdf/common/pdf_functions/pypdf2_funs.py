"""
common/pdf_functions/pypdf2_funs.py

Author: Benevant Mathew
Date: 2026-06-21
"""
import PyPDF2

def save_pages_of_pdf(page_nos,file,outputfile):
    #PyPDF2
    # page_nos  should in comma seperated
    reader = PyPDF2.PdfReader(file)
    writer = PyPDF2.PdfWriter()

    # Get the pages from the input string
    pages=[int(x) for x in page_nos.split(',')]

    # Add specified pages to the writer
    for n in pages:
        writer.add_page(reader.pages[n - 1])  # Use reader.pages to access the page
    output = open(outputfile,'wb')
    writer.write(output)
    output.close()

def merge_pdfs(pdf_list, output_file):
    # Create a PDF writer object
    pdf_writer = PyPDF2.PdfWriter()

    # Loop through all the PDF files
    for pdf in pdf_list:
        # Open the current PDF file in binary read mode
        with open(pdf, 'rb') as file:
            # Create a PDF reader object for the current PDF
            pdf_reader = PyPDF2.PdfReader(file)

            # Append each page of the PDF to the writer object
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                pdf_writer.add_page(page)

    # Write the combined PDF to the output file
    with open(output_file, 'wb') as output_pdf:
        pdf_writer.write(output_pdf)
