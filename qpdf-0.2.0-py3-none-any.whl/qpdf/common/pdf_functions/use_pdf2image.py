"""
common/pdf_functions/use_pdf2image.py

Author: Benevant Mathew
Date: 2026-06-21
"""
import os
import fitz  # pymupdf
from PIL import Image
class Pdf2imageCore:
    def __init__(self):
        """
        Initialize Pdf2imageCore class.
        """
        pass
    def pdf2image_fun(self, filelist,output_dir, dpi):
        """
        Convert PDF files into images.

        :param filelist: List of PDF file paths (or a single file path as a string).
        :param output_dir: Directory where the output images will be saved.
        :param dpi: DPI (dots per inch) for image quality.
        :return: Dictionary with PDF file paths as keys and lists of image file paths as values.
        """
        if isinstance(filelist, str):
            filelist = [filelist]
        out_dict = {}
        for filepath in filelist:
            doc = fitz.open(filepath)  # Open PDF using pymupdf
            filename=os.path.basename(filepath)
            basename = filename[:-4]
            out_dict[filepath] = []
            # out file dir
            output_file_dir=os.path.join(output_dir,basename)
            os.makedirs(output_file_dir,exist_ok=True)
            for i, page in enumerate(doc):
                pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72))  # Adjust DPI
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                newpath = os.path.join(output_file_dir, f'{basename}_page_{i}.jpg')
                img.save(newpath, 'JPEG')
                out_dict[filepath].append(newpath)
        return out_dict
