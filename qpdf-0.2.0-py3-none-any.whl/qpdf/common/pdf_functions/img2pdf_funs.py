"""
common/pdf_functions/img2pdf_funs.py

Author: Benevant Mathew
Date: 2026-06-21
"""
import img2pdf


class Img2pdfCore:
    def __init__(self):
        """
        Initialize the Img2pdfCore class.
        """
        pass
    def images_to_pdf(self, image_paths, output_pdf_path):
        """
        Convert a list of images into a single PDF.
        :param image_paths: List of paths to the image files.
        :param output_pdf_path: Path to save the generated PDF file.
        """
        try:
            # Open all image files in binary mode
            image_files = [open(image_path, 'rb') for image_path in image_paths]
            # Write the images to a PDF file
            with open(output_pdf_path, 'wb') as pdf_file:
                pdf_file.write(img2pdf.convert(image_files))
        finally:
            # Close all opened image files
            for file in image_files:
                file.close()
