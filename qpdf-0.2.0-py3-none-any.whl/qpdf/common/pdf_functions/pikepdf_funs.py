"""
common/pdf_functions/pikepdf_funs.py

Author: Benevant Mathew
Date: 2026-06-21
"""
import pikepdf

def decode_pdf(input_pdf_path,output_pdf_path,password):
	pdf = pikepdf.open(input_pdf_path, password=password)
	pdf.save(output_pdf_path)
	print('function completed for {}'.format(input_pdf_path))
