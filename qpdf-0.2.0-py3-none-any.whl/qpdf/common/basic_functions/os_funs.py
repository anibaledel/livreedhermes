"""
common/basic_functions/os_funs.py

Author: Benevant Mathew
Date: 2026-06-21
"""
import os
import platform

def get_user_profile():
	if platform.system()=='Windows':
		out=os.environ['USERPROFILE']
	else:
		out=os.path.expanduser('~')
	return(out)
