"""
qpdf/main.py

Author: Benevant Mathew
Date: 2026-06-21
"""

import argparse
import sys

from qpdf.gui.gui import main as run_gui
from qpdf.help import print_help
from qpdf.version import __author__, __email__, __release_date__, __version__


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        prog="qpdf",
        description="QuantumPDF desktop PDF tools.",
        add_help=False,
    )

    parser.add_argument("-h", "--help", action="store_true")
    parser.add_argument("-v", "--version", action="store_true")
    parser.add_argument("-a", "--author", action="store_true")
    parser.add_argument("-e", "--email", action="store_true")
    parser.add_argument("-d", "--date", action="store_true")

    return parser.parse_args()


def main() -> None:
    """qpdf command line entry point."""
    args = parse_arguments()

    if args.help:
        print_help()
        sys.exit(0)

    if args.version:
        print(f"version {__version__}")
        sys.exit(0)

    if args.author:
        print(f"Author {__author__}")
        sys.exit(0)

    if args.email:
        print(f"Mailto {__email__}")
        sys.exit(0)

    if args.date:
        print(f"Release Date {__release_date__}")
        sys.exit(0)

    run_gui()


if __name__ == "__main__":
    main()
