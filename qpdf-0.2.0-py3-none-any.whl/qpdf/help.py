"""
qpdf/help.py

Author: Benevant Mathew
Date: 2026-06-21
"""


def print_help() -> None:
    help_message = """
Usage: qpdf [OPTIONS]

QuantumPDF desktop tools for merging, subsetting, decoding, and converting PDFs.

Options:
    --version, -v      Show the version of qpdf and exit
    --help, -h         Show this help message and exit
    --email, -e        Show email and exit
    --author, -a       Show author and exit
    --date, -d         Show release date and exit
    (No arguments)     Launch the GUI application
    """
    print(help_message)
