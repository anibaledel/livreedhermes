import os

from qpdf.common.pdf_functions.img2pdf_funs import Img2pdfCore


def images_to_pdf_for_dcai(img_file_paths, output_pdf_path):
    img2pdf_obj = Img2pdfCore()
    img2pdf_obj.images_to_pdf(img_file_paths, output_pdf_path)

def get_image_files_in_folder(folder_path):
    """Return sorted list of image files in the given folder."""
    valid_exts = {'.jpg', '.jpeg', '.png'}
    return sorted(
        os.path.join(folder_path, fname)
        for fname in os.listdir(folder_path)
        if os.path.splitext(fname)[1].lower() in valid_exts
    )
