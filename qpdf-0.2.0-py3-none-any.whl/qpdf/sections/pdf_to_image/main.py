from qpdf.common.pdf_functions.use_pdf2image import Pdf2imageCore

def convert_pdf2images(filepaths,output_dir,img_dpi):
	# calling pdf2image module
	pdf2image_obj=Pdf2imageCore()
	converted_images=pdf2image_obj.pdf2image_fun(filepaths,output_dir=output_dir,dpi=img_dpi)
	return converted_images
