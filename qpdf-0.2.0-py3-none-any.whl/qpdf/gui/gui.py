"""
gui/gui.py

Author: Benevant Mathew
Date: 2026-06-21
"""
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from qpdf.application.config import dpi_value
from qpdf.common.pdf_functions.pikepdf_funs import decode_pdf
from qpdf.common.pdf_functions.pypdf2_funs import merge_pdfs, save_pages_of_pdf
from qpdf.sections.pdf_to_image.main import convert_pdf2images
from qpdf.version import __app_name__, __version__


WINDOW_TITLE = f"{__app_name__} v{__version__}"
WINDOW_SIZE = "780x560"


class QuantumPDFApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.merge_files: tuple[str, ...] = ()
        self.subset_file = ""
        self.decode_file = ""
        self.convert_files: tuple[str, ...] = ()

        self.root.title(WINDOW_TITLE)
        self.root.geometry(WINDOW_SIZE)
        self.root.minsize(720, 520)

        self._configure_theme()
        self._build_layout()

    def _configure_theme(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("App.TFrame", background="#f4f7fb")
        style.configure("Header.TFrame", background="#172033")
        style.configure("HeaderTitle.TLabel", background="#172033", foreground="#ffffff", font=("Arial", 22, "bold"))
        style.configure("HeaderSubTitle.TLabel", background="#172033", foreground="#b6c2d9", font=("Arial", 10))
        style.configure("Section.TFrame", background="#ffffff", relief="flat")
        style.configure("SectionTitle.TLabel", background="#ffffff", foreground="#172033", font=("Arial", 15, "bold"))
        style.configure("Body.TLabel", background="#ffffff", foreground="#263248", font=("Arial", 10))
        style.configure("Muted.TLabel", background="#ffffff", foreground="#637089", font=("Arial", 9))
        style.configure("Footer.TLabel", background="#f4f7fb", foreground="#637089", font=("Arial", 9))
        style.configure("Accent.TButton", font=("Arial", 10, "bold"), padding=(12, 6))
        style.configure("TNotebook", background="#f4f7fb", borderwidth=0)
        style.configure("TNotebook.Tab", font=("Arial", 10, "bold"), padding=(14, 8))

    def _build_layout(self) -> None:
        container = ttk.Frame(self.root, style="App.TFrame", padding=14)
        container.pack(fill="both", expand=True)

        header = ttk.Frame(container, style="Header.TFrame", padding=(18, 14))
        header.pack(fill="x", pady=(0, 12))
        ttk.Label(header, text=__app_name__, style="HeaderTitle.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text=f"PDF merge, subset, decode, and conversion tools • Version {__version__}",
            style="HeaderSubTitle.TLabel",
        ).pack(anchor="w", pady=(3, 0))

        self.notebook = ttk.Notebook(container)
        self.notebook.pack(fill="both", expand=True)

        self._build_merge_tab()
        self._build_subset_tab()
        self._build_decode_tab()
        self._build_convert_tab()

        ttk.Label(container, text=WINDOW_TITLE, style="Footer.TLabel").pack(anchor="e", pady=(8, 0))

    def _make_tab(self, title: str, description: str) -> ttk.Frame:
        tab = ttk.Frame(self.notebook, style="Section.TFrame", padding=20)
        self.notebook.add(tab, text=title)
        ttk.Label(tab, text=title, style="SectionTitle.TLabel").pack(anchor="w")
        ttk.Label(tab, text=description, style="Muted.TLabel").pack(anchor="w", pady=(2, 16))
        return tab

    def _make_file_label(self, parent: ttk.Frame, empty_text: str = "No file selected") -> ttk.Label:
        label = ttk.Label(parent, text=empty_text, style="Muted.TLabel", justify="left", wraplength=680)
        label.pack(fill="x", pady=(8, 12))
        return label

    def _make_entry_row(self, parent: ttk.Frame, label_text: str, browse_command) -> ttk.Entry:
        ttk.Label(parent, text=label_text, style="Body.TLabel").pack(anchor="w")
        row = ttk.Frame(parent, style="Section.TFrame")
        row.pack(fill="x", pady=(5, 12))
        entry = ttk.Entry(row)
        entry.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse", command=lambda: browse_command(entry)).pack(side="left", padx=(8, 0))
        return entry

    def _select_pdf_files(self, title: str) -> tuple[str, ...]:
        files = filedialog.askopenfilenames(title=title, filetypes=[("PDF files", "*.pdf")])
        return tuple(files) if files else ()

    def _select_pdf_file(self, title: str) -> str:
        return filedialog.askopenfilename(title=title, filetypes=[("PDF files", "*.pdf")])

    def _save_as_pdf(self, entry: ttk.Entry) -> None:
        output_file = filedialog.asksaveasfilename(
            title="Save PDF As",
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
        )
        if output_file:
            entry.delete(0, tk.END)
            entry.insert(0, output_file)

    def _select_output_folder(self, entry: ttk.Entry) -> None:
        output_folder = filedialog.askdirectory(title="Select Output Folder")
        if output_folder:
            entry.delete(0, tk.END)
            entry.insert(0, output_folder)

    def _build_merge_tab(self) -> None:
        tab = self._make_tab("Merge", "Combine multiple PDF files into one output document.")
        ttk.Button(tab, text="Select PDF Files", style="Accent.TButton", command=self._select_merge_files).pack(anchor="w")
        self.merge_files_label = self._make_file_label(tab, "No PDFs selected")
        self.merge_output_entry = self._make_entry_row(tab, "Output PDF", self._save_as_pdf)
        ttk.Button(tab, text="Merge PDFs", style="Accent.TButton", command=self._merge_pdfs).pack(anchor="w", pady=(8, 0))

    def _build_subset_tab(self) -> None:
        tab = self._make_tab("Subset", "Extract selected pages from a PDF into a new file.")
        ttk.Button(tab, text="Select PDF File", style="Accent.TButton", command=self._select_subset_file).pack(anchor="w")
        self.subset_file_label = self._make_file_label(tab)
        self.subset_output_entry = self._make_entry_row(tab, "Output PDF", self._save_as_pdf)
        ttk.Label(tab, text="Pages, comma separated", style="Body.TLabel").pack(anchor="w")
        self.pages_entry = ttk.Entry(tab)
        self.pages_entry.pack(fill="x", pady=(5, 12))
        ttk.Button(tab, text="Extract Subset", style="Accent.TButton", command=self._extract_subset).pack(anchor="w", pady=(8, 0))

    def _build_decode_tab(self) -> None:
        tab = self._make_tab("Decode", "Unlock an encrypted PDF using its password.")
        ttk.Button(tab, text="Select PDF File", style="Accent.TButton", command=self._select_decode_file).pack(anchor="w")
        self.decode_file_label = self._make_file_label(tab)
        self.decode_output_entry = self._make_entry_row(tab, "Output PDF", self._save_as_pdf)
        ttk.Label(tab, text="Password", style="Body.TLabel").pack(anchor="w")
        self.password_entry = ttk.Entry(tab, show="*")
        self.password_entry.pack(fill="x", pady=(5, 12))
        ttk.Button(tab, text="Decode PDF", style="Accent.TButton", command=self._decode_pdf).pack(anchor="w", pady=(8, 0))

    def _build_convert_tab(self) -> None:
        tab = self._make_tab("Convert", "Render PDF pages to image files.")
        ttk.Button(tab, text="Select PDF Files", style="Accent.TButton", command=self._select_convert_files).pack(anchor="w")
        self.convert_files_label = self._make_file_label(tab, "No PDFs selected")
        self.convert_output_entry = self._make_entry_row(tab, "Output Folder", self._select_output_folder)
        ttk.Button(tab, text="Convert PDFs to Images", style="Accent.TButton", command=self._convert_pdfs_to_images).pack(anchor="w", pady=(8, 0))

    def _select_merge_files(self) -> None:
        files = self._select_pdf_files("Select PDF files to merge")
        if files:
            self.merge_files = files
            self.merge_files_label.config(text="\n".join(files))

    def _select_subset_file(self) -> None:
        selected_file = self._select_pdf_file("Select PDF file")
        if selected_file:
            self.subset_file = selected_file
            self.subset_file_label.config(text=selected_file)

    def _select_decode_file(self) -> None:
        selected_file = self._select_pdf_file("Select PDF file")
        if selected_file:
            self.decode_file = selected_file
            self.decode_file_label.config(text=selected_file)

    def _select_convert_files(self) -> None:
        files = self._select_pdf_files("Select PDF files to convert")
        if files:
            self.convert_files = files
            self.convert_files_label.config(text="\n".join(files))

    def _require_output_path(self, entry: ttk.Entry) -> str:
        return entry.get().strip()

    def _merge_pdfs(self) -> None:
        output_file = self._require_output_path(self.merge_output_entry)
        if not self.merge_files or not output_file:
            messagebox.showwarning("Missing input", "Please select PDF files and specify an output PDF.")
            return
        merge_pdfs(self.merge_files, output_file)
        messagebox.showinfo("Success", f"Merged PDF saved to:\n{output_file}")

    def _extract_subset(self) -> None:
        output_file = self._require_output_path(self.subset_output_entry)
        pages = self.pages_entry.get().strip()
        if not self.subset_file or not output_file or not pages:
            messagebox.showwarning("Missing input", "Please select a PDF, enter pages, and specify an output PDF.")
            return
        save_pages_of_pdf(pages, self.subset_file, output_file)
        messagebox.showinfo("Success", f"PDF subset saved to:\n{output_file}")

    def _decode_pdf(self) -> None:
        output_file = self._require_output_path(self.decode_output_entry)
        password = self.password_entry.get()
        if not self.decode_file or not output_file or not password:
            messagebox.showwarning("Missing input", "Please select a PDF, enter a password, and specify an output PDF.")
            return
        decode_pdf(self.decode_file, output_file, password)
        messagebox.showinfo("Success", f"Decoded PDF saved to:\n{output_file}")

    def _convert_pdfs_to_images(self) -> None:
        output_folder = self._require_output_path(self.convert_output_entry)
        if not self.convert_files or not output_folder:
            messagebox.showwarning("Missing input", "Please select PDF files and an output folder.")
            return
        Path(output_folder).mkdir(parents=True, exist_ok=True)
        convert_pdf2images(self.convert_files, output_folder, dpi_value)
        messagebox.showinfo("Success", f"Images saved under:\n{output_folder}")


def main() -> None:
    root = tk.Tk()
    QuantumPDFApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
