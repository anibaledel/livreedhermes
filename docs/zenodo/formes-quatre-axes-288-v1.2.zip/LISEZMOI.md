# Les 288 formes à quatre axes de miroir — La Livrée d'Hermès, version 1.2

**v1.1** : correction de `grilles_distinctes_sur_64` pour les bases B, C et D (32 au lieu de 64) ; rien d'autre ne change (mêmes grilles, mêmes couples, mêmes images).

**v1.2** : correction du script de reproduction, qui écrivait 64 pour les bases B, C et D (`repro/tools/formes_quatre_axes_lecture.mjs` : une ligne) ; rien d'autre ne change (mêmes données, mêmes grilles, mêmes couples, mêmes images).

**Auteur** : Anibal Edelberto Amiot (ORCID 0009-0002-6414-9448). **Licence** : données et images CC BY-NC 4.0 ; scripts AGPL v3 (licence commerciale sur demande).
**Dépôts liés** : corpus tricolore de 256 grilles, DOI 10.5281/zenodo.24396534 ; jeu complet des 360 plaques, 10.5281/zenodo.23189276 ; jeu unifié (96 plaques), 10.5281/zenodo.24508469.
**Code et calculs** : https://github.com/anibaledel/livreedhermes (commit 9512aa637, `docs/article-parallele-unified-patterns.md`).

## Ce que contient ce dépôt
Une famille de **288 formes** de pavages 12 × 12 à trois teintes (violet V, magenta M, orange O) qui ont **quatre axes de miroir** (vertical, horizontal et les deux diagonales), un seul motif au pavage
(le décalage de six cases dans chaque direction échange deux teintes), 48 / 48 / 48 cases par teinte, et qui sont **lisibles par la lecture binaire du corpus** (72 sombres / 72 clairs, lecture inversée par le décalage).
- **32 formes** sont celles du corpus déjà déposé (celles de ses 64 formes qui ont quatre axes) ;
- **256 formes** sont nouvelles : elles se construisent avec des **couches nouvelles**, symétriques autour du centre de la cellule, qui ne font pas partie des 360 plaques du jeu complet.
Chaque forme est donnée par une grille représentante (une forme = une classe à translation torique près).

## Fichiers
- `data/formes-quatre-axes-288.json` : les 288 formes (identifiant `q4-NNN`, indicateur `corpus`, `socle_par_niveau`, `grilles_distinctes_sur_64`, `tricolore` en 12 lignes de lettres V/M/O) et les 288 couples de couches `{A, B = π∘A}` qui les engendrent (`couples`).
- `data/formes-quatre-axes-288.csv` : les mêmes formes en tableau.
- `data/couches-quatre-axes.json` : les 3 552 couples de couches à quatre axes dont ces 288 couples sont les parfaits à la lecture binaire.
- `svg/` : une image SVG par forme (une cellule 12 × 12). `planches/` : trois planches (pavage 2 × 2) — les 288 formes, rangées par type de socle, et les 64 formes du corpus.
- `repro/` : les scripts qui recalculent tout (à lancer depuis une copie du dépôt, aux mêmes chemins relatifs ; `data/referent_360_v3.json` et `data/corpus-256.json` sont ceux des dépôts cités).
- `SHA256SUMS.txt` : les empreintes des fichiers.

## Les cinq socles
Le socle d'une grille est l'ensemble de ses 48 cases de la teinte fixe. Seuls cinq socles passent la lecture binaire :
| Type | Cases fixes par niveau 1 à 6 | Formes | Grilles distinctes sur les 64 hexagrammes |
|---|---|---|---|
| corpus | 8, 8, 8, 8, 8, 8 | 32 | 64 (les six traits pèsent le même poids : distance = 16 × distance de Hamming) |
| A | 8, 16, 0, 8, 8, 8 | 64 | 64 (poids inégaux) |
| B | 0, 8, 0, 8, 24, 8 | 64 | 32 (le trait 5 ne change rien) |
| C | 8, 0, 0, 8, 24, 8 | 64 | 32 (le trait 5 ne change rien) |
| D | 24, 0, 0, 8, 8, 8 | 64 | 32 (le trait 1 ne change rien) |

## Limites
- Les 256 formes nouvelles **ne ferment pas le cube** (théorème 3 de la note « demi-décalage ») ; les plaques de leurs couches n'ont pas été étudiées.
- Seules les formes dont les axes passent **entre les cases** sont atteintes avec la carte des six niveaux du système ; 3 200 autres formes parfaites à quatre axes (axes sur le milieu des cases) existent et demandent une autre carte.
- Aucune signification n'est attribuée aux motifs. Le rapport avec les hexagrammes (un hexagramme = un mot de six bits = un choix de couche par niveau) vaut pour le type de socle « corpus » ; pour les autres, deux hexagrammes peuvent donner la même grille ou des poids inégaux.

# English summary
The family of **288 three-colour 12 × 12 tilings with four mirror axes**, a single motif (the half-period shift swaps two colours), 48 / 48 / 48 cells per colour, and readable by the corpus binary reading. 32 are the four-axis forms of the deposited corpus,
256 are new and need new layers outside the 360 plates. Files: JSON/CSV data, one SVG per form, three PNG sheets, and the scripts that recompute everything. Licence CC BY-NC 4.0 (data), AGPL v3 (scripts).
