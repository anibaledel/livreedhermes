# Data and verification scripts: "A half-shift criterion on three-colour 12 × 12 grids, and its restriction on the cube" (version 4)

Author: Anibal Edelberto Amiot (ORCID 0009-0002-6414-9448). No institutional affiliation.

This record holds the data and the scripts behind every number of the note, and the figures they regenerate. It is a record of the author; the note is a manuscript and is not claimed to be peer-reviewed.

- All versions of this record: https://doi.org/10.5281/zenodo.22862110
- The treatise from which the construction derives (this record is a supplement to it): https://doi.org/10.5281/zenodo.22722485
- The 360 plates (Chapter VIII, the game): https://doi.org/10.5281/zenodo.23189275

## This version is complete by itself

A Zenodo version does not inherit the files of the previous one; every file of this version is in this archive. Nothing is to be taken from an earlier version. See `CHANGES.md` for what differs from version 3.

## Layout (keep it when you extract)

```
tools/   the scripts            data/   the three reference files
logs/    the output of each script (one .log per script, and durees.txt)
fig/     the figures the scripts write
realisation/   the stitch chart and the sewing net of the cube (a proposal; nothing was stitched or woven)
```

The scripts resolve their data with `REPO_ROOT = parent of tools/` and look for `data/referent_360_v3.json`: flattening the archive makes them fail with « données introuvables ». Run them from `tools/`.

## Quick start

```
cd tools
python3 cube_edges.py                    # the corpus: 1024 triples, 512 grids, 256 classes modulo the half-shift; the cube; Lemma and orbit counts
python3 cube_edges.py --rotations-only   # panels that can be turned but not turned over: the same four families
python3 rotations_orientees.py           # the same question recomputed from the geometry of the cube
python3 classes_translations.py          # 512 grids modulo the half-shift and modulo all 144 translations
python3 croisements.py                   # the extension across families (Appendix A of the note)
```

To confirm a run, compare its output with the file in `logs/`, every line **except the last one** (the running time). `sha256sum -c SHA256SUMS.txt` checks the archive.

Requirements: Python 3.13 (3.11 for version 3); no third-party package, except `reportlab` for the four scripts that write PDF figures (`make_patron.py`, `make_exemple.py`, `make_pavage.py`, `make_broderie.py`).

## Licence

Code: AGPL v3 (a commercial licence is available on request). For the data files, see the licence field of the Zenodo record.
