# Changes from the first anonymised submission (all in latex/half-shift-cube.tex, plus two scripts and two figures)

The PDFs of the first submission are NOT included: they no longer match the source. Recompile `latex/half-shift-cube.tex` (not done here: no LaTeX in the session that made the edit).

1. Setup: a family is *indexed* by a subset of the four bases and always carries four layers; "-mut" is a catalogue label, B = A∘σ holds in some families only.
2. Definition (section 3): "one spatial period" removed; σ is a colour symmetry, the coloured tiling keeps period 12.
3. Counts (section 4): 512 grids; 256 classes modulo ⟨σ⟩ (the "tilings"); 128 classes modulo all translations, because (6,0) and (0,6) preserve the set. New `tools/classes_translations.py`.
4. Corollary 4: proof from (F3)–(F5) alone (κσ = σκ, A surjective, centraliser of a transposition in S3).
5. Section 6 (cube): the D4 assumption is stated; with rotations only, only {yang} and {yang, yin-mut} remain (128 grids, 64 classes modulo σ), from `cube_edges.py --rotations-only`. Admissibility is not invariant under (6,0), (0,6). The three-fold-symmetry sentence is replaced by what Proposition 1 proves. New Figure 5 (net, with lettered glued edges), made by new `tools/make_patron.py`.
6. Data section and claims updated.
