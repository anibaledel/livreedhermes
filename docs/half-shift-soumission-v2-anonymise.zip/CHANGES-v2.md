# Second anonymised submission: what changed from the first (latex/half-shift-cube.tex, scripts, figures)

The PDF of the manuscript is NOT included: it must be compiled (`pdflatex`, class `interact`) before submission. It could not be compiled where the sources were edited.

Corrections that follow the audit of the first version
1. Vocabulary (section 2): a family is *indexed* by a subset of the four bases and always carries four layers; "-mut" is a catalogue label; a correspondence with the diagonal/orthogonal bases D, D*, P, P* is given.
2. Counts (section 4): 512 grids; 256 classes modulo the half-shift; 128 classes modulo all 144 translations, computed exhaustively (`tools/classes_translations.py`), not inferred from two translations.
3. Corollary 4: proof from (F3)-(F5) alone.
4. Section 6: three-fold symmetry at a vertex is no longer claimed; a net of the cube with lettered seams (Figure 5, `tools/make_patron.py`, label boxes now drawn white).
5. **Rotations only.** The earlier statement that rotations alone keep only two of the four families is WITHDRAWN: it came from rotating faces in arbitrary frames, some seen from outside and some from inside. With every face framed seen from outside (right-handed), `tools/rotations_orientees.py` (independent recomputation from the cell adjacency) and `tools/cube_edges.py --rotations-only` (now oriented) give the same four families, 256 grids and 128 classes as the full dihedral group.
6. Introduction: the statement that the mathematics "makes no use" of the weaving system is replaced by an explicit textile reading with its limits; "the cube wants yang" is replaced by the unshifted diagonal phase.
7. Section 8: a proposed realisation (counted cross-stitch, six panels sewn along lettered seams), with a stitch chart and a net, `tools/make_broderie.py`, `realisation/schema-broderie-n21.pdf`. Nothing was stitched or woven; no claim about a loom.

Package
- `supplementary/logs/` : the output of every script of the package (compare every line except the last; one line of `croisements.log` and the last lines are running times). `durees.txt` gives each running time on the machine used.
- `supplementary/SHA256SUMS.txt` lists every file of `supplementary/` except itself: `cd supplementary && sha256sum -c SHA256SUMS.txt`.
- No `__pycache__`.
- `tools/cube_edges.py` here differs from the deposited version only in the oriented `--rotations-only` option and its documentation.

Not done
- Section 7 (extension across families) is not yet reduced to the geometric statement about levels 2 and 5; the detailed counts are still in the main text.
- Bibliography: no references added beyond the four of the first version.
